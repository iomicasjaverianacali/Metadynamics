#!/bin/bash
#SBATCH --job-name=metadynamics
#SBATCH --output=logfile.metadynamics.%A.log
#SBATCH --partition=GPU
#SBATCH --nodes=1
#SBATCH --tasks-per-node=40
#SBATCH --mem=100G
#SBATCH --gres=gpu:3

module load NAMD/2.14_cuda
#module load NAMD/2.14_mpi
##export LD_LIBRARY_PATH=/sw/apps/LAMMPS/2018.12.12/src/src:$LD_LIBRARY_PATH
##module load mpi/openmpi

export scratch_dir=/scratch/pmhernandez/NAMD-JOB_$SLURM_JOB_ID
export SLURM_SUBMIT_DIR=~/paper2-MTDM_rsltsThss2Eqlbrt/MTDM_HSP163-rsltsThss2Eqlbrt/5_GA1_TotalComplex/MD_partialopen_f198-107-109/equilibrate0
export RESULTS_DIR=$SLURM_SUBMIT_DIR/results_job_$SLURM_JOB_ID

mkdir -p $scratch_dir; 
cp * $scratch_dir
cd $scratch_dir
namd2  +ppn40 +setcpuaffinity  +isomalloc_sync +idlepoll +devices 0,1,2 eq00.conf > eq00.log
#charmrun +p14 namd2 +isomalloc_sync +idlepoll +devices 0,1,2 mdm01.conf > mdm01.log
#charmrun +p14 namd2 +isomalloc_sync +idlepoll  mdm01.conf > mdm01.log



#mkdir $SLURM_SUBMIT_DIR/results_job_$SLURM_JOB_ID
#cp -r * $SLURM_SUBMIT_DIR/results_job_$SLURM_JOB_ID
mkdir $RESULTS_DIR
cp -r * $RESULTS_DIR

rm -r $scratch_dir


